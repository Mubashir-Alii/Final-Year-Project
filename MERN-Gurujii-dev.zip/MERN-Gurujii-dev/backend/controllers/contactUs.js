const { pass } = require('../config');
const nodemailer = require('nodemailer');

// const transporter = nodemailer.createTransport({
//   service: 'gmail',
//   auth: {
//     user: 'mubashirali.awan88@gmail.com',
//     pass: `jn7jnAPss4f63QBp6D`,
//   },
// });

const transporter = nodemailer.createTransport({
  host: 'smtp.gmail.com',
  port: 587,
  secure: false, // Use `true` for port 465, `false` for all other ports
  auth: {
    user: 'mubashirali.awan88@gmail.com',
    pass: 'coxpfdrmhrglidvq',
  },
});

exports.sendMail = (req, res) => {
  const { name, email, message, subject } = req.body;

  const options = {
    from: 'mubashirali.awan88@gmail.com',
    to: 'mubashirali.awan88@gmail.com',
    subject: `${subject}`,
    text: `From:`,
    html: `<p>From: ${email}<br>Name : ${name}<br>Message: ${message}</p>`,
  };

  transporter.sendMail(options, err => {
    if (err) {
      console.log(err);
      res.status(500).json({
        message: 'server error occured!',
      });
    } else {
      console.log('message sent');

      res.status(200).json({
        message: 'feedback sent successful',
      });
    }
  });
};
