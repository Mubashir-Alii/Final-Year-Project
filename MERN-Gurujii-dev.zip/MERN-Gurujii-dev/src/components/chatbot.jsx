import React from 'react';
import ChatBot from 'react-simple-chatbot';
// import { ThemeProvider } from 'styled-components';

// const theme = {
//   background: '#f5f8fb',
//   fontFamily: 'Helvetica Neue',
//   headerBgColor: '#EF6C00',
//   headerFontColor: '#fff',
//   headerFontSize: '15px',
//   botBubbleColor: '#EF6C00',
//   botFontColor: '#fff',
//   userBubbleColor: '#fff',
//   userFontColor: '#4a4a4a',
// };

const config = {
  width: '400px',
  height: '500px',
  floating: true,
  floatingStyle: {
    right: '15px',
    bottom: '60px',
    width: '40px',
    height: '40px',
  },
  headerTitle: 'Chat Help',
};

const steps = [
  {
    id: 'intro',
    message: 'Hello! Nice to see you here.',
    trigger: 'intro2',
  },
  {
    id: 'intro2',
    message: 'I am your assistant. How can I help you today?',
    trigger: 'intro3',
  },
  {
    id: 'intro3',
    message: 'Are you a teacher or student?',
    trigger: 'intro-user',
  },
  {
    id: 'intro-user',
    options: [
      { value: 't', label: 'Teacher', trigger: 'teacher' },
      { value: 's', label: 'Student', trigger: 'student' },
    ],
  },
  {
    id: 'teacher',
    message: 'Ok Sir/Madam, you can login with your Google account.',
    trigger: 'teacher2',
  },
  {
    id: 'teacher2',
    message:
      'After login, you can create your teacher profile which will be available on our site.',
    trigger: 'teacher-form',
  },
  {
    id: 'teacher-form',
    message: 'Would you like to provide your teaching subjects?',
    trigger: 'teacher-form-options',
  },
  {
    id: 'teacher-form-options',
    options: [
      { value: 'yes', label: 'Yes', trigger: 'teacher-subjects' },
      { value: 'no', label: 'No', trigger: 'end' },
    ],
  },
  {
    id: 'teacher-subjects',
    component: (
      <div>
        <p>Please enter your subjects:</p>
        <input type="text" placeholder="Enter subjects" />
      </div>
    ),
    trigger: 'end',
  },
  {
    id: 'student',
    message:
      'Ok buddy, you are at the right place. At Gurujii, you will find the best teachers.',
    trigger: 'student-followup',
  },
  {
    id: 'student-followup',
    message: 'Do you need help finding a teacher or something else?',
    trigger: 'student-help-options',
  },
  {
    id: 'student-help-options',
    options: [
      { value: 'find_teacher', label: 'Find a teacher', trigger: 'find-teacher' },
      { value: 'other', label: 'Other', trigger: 'end' },
    ],
  },
  {
    id: 'find-teacher',
    message: 'What subject are you interested in?',
    trigger: 'find-teacher-subject',
  },
  {
    id: 'find-teacher-subject',
    component: (
      <div>
        <input type="text" placeholder="Enter subject" />
      </div>
    ),
    trigger: 'end',
  },
  {
    id: 'end',
    message: 'If you need any more help, feel free to ask!',
    end: true,
  },
];

const ChatBotComponent = () => {
  return (
    // <ThemeProvider theme={theme}>
    <ChatBot
      steps={steps}
      {...config}
      recognitionEnable={
        JSON.parse(window.localStorage.getItem('muted')) ? true : false
      }
      speechSynthesis={{
        enable: JSON.parse(window.localStorage.getItem('muted')) ? true : false,
        lang: 'en',
      }}
    />
    // </ThemeProvider>
  );
};

export default ChatBotComponent;
