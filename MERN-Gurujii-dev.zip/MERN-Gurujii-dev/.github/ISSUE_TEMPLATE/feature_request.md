---
name: "\U0001F680 Feature Request"
about: Suggest an idea for this project
title: ''
labels: ''
assignees: ''

---

**Describe the feature you'd like to add**
A clear and concise description of what you want to happen.

**Describe how you will do it**
A clear and concise description of how you will do it.

**Additional context**
Add any other context or screenshots about the feature request here.
